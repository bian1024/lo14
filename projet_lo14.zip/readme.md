Ce projet a pour objectif de creer un reseau virtuel de machine linux
